package com.trace.decoder.views;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.part.ViewPart;

public class TraceDecoderView extends ViewPart {

    // FILE PATHS
    private static final String BASE =
        "D:\\trace-project\\workspace\\pipeline_out\\";

    private static final String UNIFIED_CSV  = BASE + "unified_profiling_report.csv";
    private static final String SYSTEM_TRACE = BASE + "system_trace.txt";
    private static final String ETRACE_FILE  = BASE + "spike_pc_trace_input.decoder.trace";
    private static final String CACHE_CSV    = BASE + "rtl_profiling_report.csv";
    private static final String TRIGGER_FILE = BASE + "pipeline_done.trigger";


    private static final int C_FUNCTION            =  0;
    private static final int C_PC_START            =  1;
    private static final int C_PC_END              =  2;
    private static final int C_SOURCE_LOCATION     =  3;
    private static final int C_TOTAL_CYCLES        =  6;
    private static final int C_PCT_OF_PROGRAM      =  7;
    private static final int C_CPI                 =  8;  
    private static final int C_CALLS               =  9;
    private static final int C_AVG_CYCLES_PER_CALL = 10;
    private static final int C_INSTR_COUNT         = 11;
    private static final int C_ICACHE_MISSES       = 19;
    private static final int C_DCACHE_MISSES       = 20;
    private static final int C_TOTAL_CACHE_MISSES  = 21;

    // WIDGETS
    private Text       statusText;
    private CTabFolder tabFolder;

    private Table unifiedTable;
    private Table systemTable;
    private Table etraceTable;
    private Table cacheTable;

    // WATCHER STATE
    private volatile boolean watcherRunning  = false;
    private          long    lastTriggerTime = 0;

    // CREATE UI
    @Override
    public void createPartControl(Composite parent) {

        parent.setLayout(new GridLayout(1, false));

        // STATUS BAR
        statusText = new Text(parent, SWT.BORDER | SWT.READ_ONLY);
        statusText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
        statusText.setText("Loading pipeline results...");

        // TAB FOLDER
        tabFolder = new CTabFolder(parent, SWT.BORDER | SWT.BOTTOM);
        tabFolder.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
        tabFolder.setSimple(false);

        buildTab1_UnifiedProfiling();
        buildTab2_SystemTrace();
        buildTab3_ETrace();
        buildTab4_CacheMisses();

        tabFolder.setSelection(0);

        loadAllTabs();
        startTriggerWatcher();
    }


    // TAB BUILDERS


    private void buildTab1_UnifiedProfiling() {
        CTabItem tab = new CTabItem(tabFolder, SWT.NONE);
        tab.setText("Unified Profiling");

        Composite comp = new Composite(tabFolder, SWT.NONE);
        comp.setLayout(new GridLayout(1, false));

        unifiedTable = new Table(comp,
            SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
        unifiedTable.setHeaderVisible(true);
        unifiedTable.setLinesVisible(true);
        unifiedTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

        // 13 columns (CPI added)
        String[][] cols = {
            {"Function",          "200"},   //  0  C_FUNCTION
            {"PC Start",          "120"},   //  1  C_PC_START
            {"PC End",            "120"},   //  2  C_PC_END
            {"Source Location",   "180"},   //  3  C_SOURCE_LOCATION
            {"Total Cycles",      "110"},   //  6  C_TOTAL_CYCLES
            {"% of Program",      "100"},   //  7  C_PCT_OF_PROGRAM
            {"CPI",                "70"},   //  8  C_CPI            ← NEW
            {"Calls",              "70"},   //  9  C_CALLS
            {"Avg Cyc/Call",      "110"},   // 10  C_AVG_CYCLES_PER_CALL
            {"Instr Count",       "100"},   // 11  C_INSTR_COUNT
            {"I$ Misses",         "100"},   // 19  C_ICACHE_MISSES
            {"D$ Misses",         "100"},   // 20  C_DCACHE_MISSES
            {"Total Cache Miss",  "130"},   // 21  C_TOTAL_CACHE_MISSES
        };
        for (String[] hw : cols) {
            TableColumn c = new TableColumn(unifiedTable, SWT.NONE);
            c.setText(hw[0]);
            c.setWidth(Integer.parseInt(hw[1]));
        }

        tab.setControl(comp);
    }

    private void buildTab2_SystemTrace() {
        CTabItem tab = new CTabItem(tabFolder, SWT.NONE);
        tab.setText("System Trace");

        Composite comp = new Composite(tabFolder, SWT.NONE);
        comp.setLayout(new GridLayout(1, false));

        systemTable = new Table(comp,
            SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
        systemTable.setHeaderVisible(true);
        systemTable.setLinesVisible(true);
        systemTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

        for (String[] hw : new String[][]{
            {"Cycle","100"}, {"PC","170"}, {"Mnemonic","100"},
            {"Event","90"},  {"Function","150"}, {"Reg Delta","200"}, {"Mem Access","180"}
        }) {
            TableColumn c = new TableColumn(systemTable, SWT.NONE);
            c.setText(hw[0]);
            c.setWidth(Integer.parseInt(hw[1]));
        }
        tab.setControl(comp);
    }

    private void buildTab3_ETrace() {
        CTabItem tab = new CTabItem(tabFolder, SWT.NONE);
        tab.setText("E-Trace");

        Composite comp = new Composite(tabFolder, SWT.NONE);
        comp.setLayout(new GridLayout(1, false));

        etraceTable = new Table(comp,
            SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
        etraceTable.setHeaderVisible(true);
        etraceTable.setLinesVisible(true);
        etraceTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

        for (String[] hw : new String[][]{{"#","70"}, {"PC Address","200"}}) {
            TableColumn c = new TableColumn(etraceTable, SWT.NONE);
            c.setText(hw[0]);
            c.setWidth(Integer.parseInt(hw[1]));
        }
        tab.setControl(comp);
    }

    private void buildTab4_CacheMisses() {
        CTabItem tab = new CTabItem(tabFolder, SWT.NONE);
        tab.setText("Cache Misses");

        Composite comp = new Composite(tabFolder, SWT.NONE);
        comp.setLayout(new GridLayout(1, false));

        cacheTable = new Table(comp,
            SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
        cacheTable.setHeaderVisible(true);
        cacheTable.setLinesVisible(true);
        cacheTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

        for (String[] hw : new String[][]{
            {"Function","200"}, {"I$ Misses","120"},
            {"D$ Misses","120"}, {"Total Misses","120"}
        }) {
            TableColumn c = new TableColumn(cacheTable, SWT.NONE);
            c.setText(hw[0]);
            c.setWidth(Integer.parseInt(hw[1]));
        }
        tab.setControl(comp);
    }


    // LOAD ALL TABS

    private void loadAllTabs() {
        loadUnified();
        loadSystemTrace();
        loadETrace();
        loadCacheMisses();
    }


    // TAB 1: UNIFIED PROFILING


    private void loadUnified() {
        unifiedTable.removeAll();

        File file = new File(UNIFIED_CSV);
        if (!file.exists()) {
            statusText.setText("Waiting for: " + UNIFIED_CSV);
            return;
        }

        int loaded = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean firstLine = true;

            while ((line = br.readLine()) != null) {
                if (firstLine) { firstLine = false; continue; } // skip CSV header

                // -1 limit keeps trailing empty tokens so index 21 is always present
                String[] p = line.split(",", -1);

                TableItem item = new TableItem(unifiedTable, SWT.NONE);
                item.setText(new String[]{
                    safeGet(p, C_FUNCTION),             //  0
                    safeGet(p, C_PC_START),             //  1
                    safeGet(p, C_PC_END),               //  2
                    safeGet(p, C_SOURCE_LOCATION),      //  3
                    safeGet(p, C_TOTAL_CYCLES),         //  6
                    safeGet(p, C_PCT_OF_PROGRAM),       //  7
                    safeGet(p, C_CPI),                  //  8
                    safeGet(p, C_CALLS),                //  9
                    safeGet(p, C_AVG_CYCLES_PER_CALL),  // 10
                    safeGet(p, C_INSTR_COUNT),          // 11
                    safeGet(p, C_ICACHE_MISSES),        // 19
                    safeGet(p, C_DCACHE_MISSES),        // 20
                    safeGet(p, C_TOTAL_CACHE_MISSES),   // 21
                });
                loaded++;
            }

            statusText.setText("All tabs loaded ✔  —  " + loaded + " functions in Unified Profiling");

        } catch (Exception e) {
            statusText.setText("Unified CSV error: " + e.getMessage());
        }
    }

    // TAB 2: SYSTEM TRACE
    private void loadSystemTrace() {
        systemTable.removeAll();

        File file = new File(SYSTEM_TRACE);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            int count = 0;
            boolean first = true;

            while ((line = br.readLine()) != null && count < 5000) {
                if (first) { first = false; continue; }
                if (line.startsWith("---") || line.startsWith("[SUMMARY]") || line.trim().isEmpty()) continue;

                String[] parts = line.trim().split("\\s{2,}");
                if (parts.length < 2) continue;

                TableItem item = new TableItem(systemTable, SWT.NONE);
                item.setText(new String[]{
                    safeGet(parts, 0),  // Cycle
                    safeGet(parts, 1),  // PC
                    safeGet(parts, 2),  // Mnemonic
                    safeGet(parts, 3),  // Event
                    safeGet(parts, 4),  // Function
                    safeGet(parts, 5),  // Reg Delta
                    safeGet(parts, 6),  // Mem Access
                });
                count++;
            }
        } catch (Exception e) {
            statusText.setText("System trace error: " + e.getMessage());
        }
    }

    // TAB 3: E-TRACE  (first 5000 PC addresses)
    private void loadETrace() {
        etraceTable.removeAll();

        File file = new File(ETRACE_FILE);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            int count = 1;
            while ((line = br.readLine()) != null && count <= 5000) {
                String pc = line.trim();
                if (pc.isEmpty()) continue;
                TableItem item = new TableItem(etraceTable, SWT.NONE);
                item.setText(new String[]{ String.valueOf(count), "0x" + pc });
                count++;
            }
        } catch (Exception e) {
            statusText.setText("E-Trace error: " + e.getMessage());
        }
    }

    // TAB 4: CACHE MISSES  (rtl_profiling_report.csv)
    // Columns: 0=function, 1=icache_misses, 2=dcache_misses, 3=total_misses
    private void loadCacheMisses() {
        cacheTable.removeAll();

        File file = new File(CACHE_CSV);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; continue; }
                String[] p = line.split(",", -1);
                if (p.length < 4) continue;
                TableItem item = new TableItem(cacheTable, SWT.NONE);
                item.setText(new String[]{
                    p[0].trim(),  // function
                    p[1].trim(),  // icache_misses
                    p[2].trim(),  // dcache_misses
                    p[3].trim()   // total_misses
                });
            }
        } catch (Exception e) {
            statusText.setText("Cache CSV error: " + e.getMessage());
        }
    }

    // TRIGGER FILE WATCHER
    private void startTriggerWatcher() {
        watcherRunning = true;

        Thread watcher = new Thread(() -> {
            while (watcherRunning) {
                try {
                    Thread.sleep(2000);
                    File trigger = new File(TRIGGER_FILE);
                    if (trigger.exists()) {
                        long modified = trigger.lastModified();
                        if (modified > lastTriggerTime) {
                            lastTriggerTime = modified;
                            Display.getDefault().asyncExec(() -> {
                                statusText.setText("New pipeline results detected — reloading...");
                                loadAllTabs();
                            });
                        }
                    }
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception ex) {
                    // silently ignore watcher errors
                }
            }
        });

        watcher.setDaemon(true);
        watcher.start();
    }

    private static String safeGet(String[] arr, int idx) {
        if (arr == null || idx < 0 || idx >= arr.length) return "";
        return arr[idx].trim();
    }

    // CLEANUP
    @Override
    public void dispose() {
        watcherRunning = false;
        super.dispose();
    }

    @Override
    public void setFocus() {
        tabFolder.setFocus();
    }
}