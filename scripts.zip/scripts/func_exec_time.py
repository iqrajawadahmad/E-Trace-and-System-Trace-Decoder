#!/usr/bin/env python3
import re
import os
import csv
import sys
import argparse
from collections import defaultdict


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--trace",  required=True, help="system_trace.txt")
    p.add_argument("--outdir", default=".",   help="Output directory")
    return p.parse_args()


# hex address from REG_DELTA e.g. "a5=0x80026020"
ADDR_RE = re.compile(r'=\s*(0x[0-9a-fA-F]+)', re.IGNORECASE)


def parse_trace(path):
    rows = []
    header_done = False

    with open(path, "r", errors="replace") as f:
        for line in f:
            stripped = line.strip()

            if not header_done:
                if stripped.startswith("CYCLE") or stripped.startswith("---"):
                    header_done = True
                continue

            if not stripped or stripped.startswith("["):
                continue

            parts = re.split(r'\s{2,}', stripped)
            if len(parts) < 5:
                continue

            try:
                cycle = int(parts[0])
            except ValueError:
                continue

            event     = parts[3].strip().upper() if len(parts) > 3 else ""
            func      = parts[4].strip()         if len(parts) > 4 else "?"
            reg_delta = parts[5].strip()         if len(parts) > 5 else "-"

            if func in ("?", "...", "FUNC", "") or "htif" in func.lower():
                continue

            mem_addr = None
            if event in ("LOAD", "STORE") and reg_delta not in ("-", ""):
                m = ADDR_RE.search(reg_delta)
                if m:
                    mem_addr = m.group(1).lower()

            rows.append({
                "cycle":    cycle,
                "func":     func,
                "event":    event,
                "mem_addr": mem_addr,
            })

    print(f"[INFO] {len(rows):,} trace rows parsed")
    return rows


def compute_func_stats(rows):
    stats = defaultdict(lambda: {
        "self_cycles":  0,
        "entry_cycle":  None,
        "exit_cycle":   None,
        "instr_count":  0,
        "calls":        0,
        "exec_count":   0,
        "load_count":   0,
        "store_count":  0,
        "branch_count": 0,
        "mem_addrs":    set(),
        "_call_entry":  {},
        "_call_spans":  [],
    })

    call_stack = []

    for i, row in enumerate(rows):
        cycle = row["cycle"]
        func  = row["func"]
        event = row["event"]
        s     = stats[func]

        s["instr_count"] += 1
        if event == "EXEC":
            s["exec_count"] += 1
        elif event == "LOAD":
            s["load_count"] += 1
            if row["mem_addr"]:
                s["mem_addrs"].add(row["mem_addr"])
        elif event == "STORE":
            s["store_count"] += 1
            if row["mem_addr"]:
                s["mem_addrs"].add(row["mem_addr"])
        elif event in ("BRANCH", "RET", "CALL"):
            s["branch_count"] += 1

        if s["entry_cycle"] is None:
            s["entry_cycle"] = cycle
        s["exit_cycle"] = cycle

        if not call_stack:
            call_stack.append(func)
            s["calls"] += 1
            s["_call_entry"][len(call_stack) - 1] = cycle
        elif call_stack[-1] != func:
            if func in call_stack:
                while call_stack and call_stack[-1] != func:
                    popped = call_stack.pop()
                    depth = len(call_stack)
                    if depth in stats[popped]["_call_entry"]:
                        span = cycle - stats[popped]["_call_entry"].pop(depth)
                        stats[popped]["_call_spans"].append(span)
            else:
                call_stack.append(func)
                s["calls"] += 1
                depth = len(call_stack) - 1
                s["_call_entry"][depth] = cycle

        if i + 1 < len(rows):
            gap = rows[i + 1]["cycle"] - cycle
            if gap > 0 and call_stack:
                stats[call_stack[-1]]["self_cycles"] += gap

    result = {}
    for fn, s in stats.items():
        calls = s["calls"] if s["calls"] > 0 else 1
        avg = s["self_cycles"] / calls
        result[fn] = {
            "self_cycles":      s["self_cycles"],
            "entry_cycle":      s["entry_cycle"]  or 0,
            "exit_cycle":       s["exit_cycle"]   or 0,
            "instr_count":      s["instr_count"],
            "calls":            s["calls"],
            "avg_cycles":       avg,
            "exec_count":       s["exec_count"],
            "load_count":       s["load_count"],
            "store_count":      s["store_count"],
            "branch_count":     s["branch_count"],
            "mem_accesses":     s["load_count"] + s["store_count"],
            "unique_mem_addrs": len(s["mem_addrs"]),
        }

    return result


CSV_FIELDS = [
    "FUNCTION",
    "ENTRY_CYCLE", "EXIT_CYCLE",
    "TOTAL_CYCLES",
    "PCT_OF_PROGRAM",
    "CPI",
    "INSTR_COUNT",
    "CALLS",
    "AVG_CYCLES_PER_CALL",
    "EXEC", "LOAD", "STORE", "BRANCH",
    "MEM_ACCESSES",
    "UNIQUE_MEM_ADDRS",
    "MEM_INTENSITY",
]


def write_csv(func_stats, total_program_cycles, outdir):
    path = os.path.join(outdir, "function_exec_time.csv")
    rows = sorted(func_stats.items(), key=lambda x: x[1]["self_cycles"], reverse=True)

    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(CSV_FIELDS)
        for func, s in rows:
            cyc = s["self_cycles"]
            ins = s["instr_count"]
            mem = s["mem_accesses"]
            pct = (cyc / total_program_cycles * 100) if total_program_cycles else 0.0
            cpi = (cyc / ins) if ins else 0.0
            mmi = (mem / cyc) if cyc else 0.0
            w.writerow([
                func,
                s["entry_cycle"],
                s["exit_cycle"],
                cyc,
                f"{pct:.2f}%",
                f"{cpi:.2f}",
                ins,
                s["calls"],
                f"{s['avg_cycles']:.1f}",
                s["exec_count"],
                s["load_count"],
                s["store_count"],
                s["branch_count"],
                mem,
                s["unique_mem_addrs"],
                f"{mmi:.4f}",
            ])

    print(f"[OK] CSV  -> {path}")
    return path


def write_txt(func_stats, total_program_cycles, total_instrs, outdir):
    path = os.path.join(outdir, "function_exec_time.txt")
    rows = sorted(func_stats.items(), key=lambda x: x[1]["self_cycles"], reverse=True)
    W = 115

    with open(path, "w") as f:
        f.write("=" * W + "\n")
        f.write("  FUNCTION EXECUTION TIME REPORT — CVA6 RISC-V\n")
        f.write("  TOTAL_CYCLES = SELF cycles (callee time excluded)\n")
        f.write("  PCT          = self_cycles / total_program_cycles\n")
        f.write("  CPI          = self_cycles / instr_count\n")
        f.write("  AVG_CYC      = self_cycles / calls\n")
        f.write(f"  Program cycles : {total_program_cycles:>12,}\n")
        f.write(f"  Instructions   : {total_instrs:>12,}\n")
        f.write("=" * W + "\n\n")

        f.write(
            f"{'FUNCTION':<22} {'SELF_CYC':>10} {'%':>7} {'CPI':>5} "
            f"{'INSTRS':>7} {'CALLS':>6} {'AVG_CYC':>8} "
            f"{'EXEC':>6} {'LOAD':>6} {'STORE':>6} {'BRANCH':>7} "
            f"{'MEM_ACC':>8} {'UNIQ_ADDR':>10} {'MEM_INT':>8}\n"
        )
        f.write("-" * W + "\n")

        for func, s in rows:
            cyc = s["self_cycles"]
            ins = s["instr_count"]
            mem = s["mem_accesses"]
            pct = (cyc / total_program_cycles * 100) if total_program_cycles else 0.0
            cpi = (cyc / ins) if ins else 0.0
            mmi = (mem / cyc) if cyc else 0.0
            fn  = (func[:21] + "~") if len(func) > 22 else func
            f.write(
                f"{fn:<22} {cyc:>10,} {pct:>6.2f}% {cpi:>5.2f} "
                f"{ins:>7,} {s['calls']:>6} {s['avg_cycles']:>8.1f} "
                f"{s['exec_count']:>6} {s['load_count']:>6} "
                f"{s['store_count']:>6} {s['branch_count']:>7} "
                f"{mem:>8} {s['unique_mem_addrs']:>10} {mmi:>8.4f}\n"
            )

        f.write("\n" + "=" * W + "\n\n")

        f.write("  TOP 5 CPU HOTSPOTS (self cycles):\n\n")
        f.write(f"  {'#':<3} {'FUNCTION':<22} {'SELF_CYC':>10} {'%':>7} "
                f"{'CPI':>5} {'INSTRS':>7} {'CALLS':>6}\n")
        f.write("  " + "-" * 68 + "\n")
        for i, (func, s) in enumerate(rows[:5], 1):
            cyc = s["self_cycles"]
            pct = (cyc / total_program_cycles * 100) if total_program_cycles else 0.0
            cpi = (cyc / s["instr_count"]) if s["instr_count"] else 0.0
            f.write(f"  {i:<3} {func:<22} {cyc:>10,} {pct:>6.2f}% "
                    f"{cpi:>5.2f} {s['instr_count']:>7,} {s['calls']:>6}\n")

        mem_rows = sorted(rows, key=lambda x: x[1]["mem_accesses"], reverse=True)
        f.write("\n  TOP 5 MEMORY-INTENSIVE FUNCTIONS:\n\n")
        f.write(f"  {'#':<3} {'FUNCTION':<22} {'MEM_ACC':>8} "
                f"{'LOAD':>7} {'STORE':>7} {'UNIQ_ADDR':>10} {'MEM_INT':>8}\n")
        f.write("  " + "-" * 73 + "\n")
        for i, (func, s) in enumerate(mem_rows[:5], 1):
            cyc = s["self_cycles"]
            mmi = (s["mem_accesses"] / cyc) if cyc else 0.0
            f.write(f"  {i:<3} {func:<22} {s['mem_accesses']:>8} "
                    f"{s['load_count']:>7} {s['store_count']:>7} "
                    f"{s['unique_mem_addrs']:>10} {mmi:>8.4f}\n")

        f.write("\n" + "=" * W + "\n")

    print(f"[OK] TXT  -> {path}")
    return path


def main():
    args = parse_args()

    if not os.path.isfile(args.trace):
        print(f"[ERROR] File not found: {args.trace}")
        sys.exit(1)

    os.makedirs(args.outdir, exist_ok=True)

    print(f"\n[STEP 1] Parsing {args.trace} ...")
    rows = parse_trace(args.trace)
    if not rows:
        print("[FATAL] No rows parsed — check trace format")
        sys.exit(1)

    print(f"\n[STEP 2] Computing self-cycle stats per function ...")
    func_stats = compute_func_stats(rows)

    total_program_cycles = rows[-1]["cycle"] - rows[0]["cycle"] if rows else 1
    total_instrs         = len(rows)
    total_self           = sum(s["self_cycles"] for s in func_stats.values())

    print(f"[INFO]   Functions          : {len(func_stats)}")
    print(f"[INFO]   Program span       : {total_program_cycles:,} cycles")
    print(f"[INFO]   Sum of self cycles : {total_self:,}")
    print(f"[INFO]   Total instructions : {total_instrs:,}")

    if total_self == 0:
        print("[FATAL] All self_cycles are 0 — check trace format")
        sys.exit(1)

    print(f"\n[STEP 3] Writing outputs to {args.outdir} ...")
    write_csv(func_stats, total_program_cycles, args.outdir)
    write_txt(func_stats, total_program_cycles, total_instrs, args.outdir)

    rows_s = sorted(func_stats.items(), key=lambda x: x[1]["self_cycles"], reverse=True)
    print("\n" + "=" * 82)
    print(f"  {'FUNCTION':<22} {'SELF_CYC':>10} {'%':>7} "
          f"{'CPI':>5} {'INSTRS':>7} {'UNIQ_ADDR':>10}")
    print("  " + "-" * 72)
    for func, s in rows_s[:10]:
        cyc = s["self_cycles"]
        pct = (cyc / total_program_cycles * 100) if total_program_cycles else 0.0
        cpi = (cyc / s["instr_count"]) if s["instr_count"] else 0.0
        print(f"  {func:<22} {cyc:>10,} {pct:>6.2f}% "
              f"{cpi:>5.2f} {s['instr_count']:>7,} "
              f"{s['unique_mem_addrs']:>10}")
    print("=" * 82)
    print(f"\n  PCT sanity check: sum = "
          f"{sum(s['self_cycles']/total_program_cycles*100 for s in func_stats.values()):.1f}% "
          f"(should be ~100%)\n")
    print("[DONE]\n")


if __name__ == "__main__":
    main()
