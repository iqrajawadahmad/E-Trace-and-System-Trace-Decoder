#!/bin/bash
#  MASTER TRACE PIPELINE
#  CVA6 Compile → Simulate → E-Trace → System Trace → Profile

set -e

#  USER CONFIG

if [ -z "$TARGET_C" ]; then
    TARGET_C=/mnt/d/riscv-work/cva6/verif/tests/custom/factorial.c
fi

ELF_NAME=simulation.elf
WORKSPACE=/mnt/d/trace-project/workspace/pipeline_out
MAX_CYCLES=0   # 0 = unlimited

#  TOOL PATHS
export SPIKE_ROOT=/mnt/d/riscv-work/cva6/tools/spike
export VERILATOR_ROOT=/mnt/d/riscv-work/cva6/tools/verilator
export RISCV=/usr
export PATH=$RISCV/bin:$VERILATOR_ROOT/bin:$SPIKE_ROOT/bin:$PATH
export DV_SIMULATORS=veri-testharness

CVA6_DIR=/mnt/d/riscv-work/cva6
GCC=/usr/bin/riscv64-unknown-elf-gcc
VERILATOR_BIN=$CVA6_DIR/work-ver/Variane_testharness

POSTISS=/mnt/d/riscv-work/riscv-trace-spec/referenceFlow/build_te/post-iss/post-iss
ENCODER=/mnt/d/riscv-work/riscv-trace-spec/referenceFlow/scripts/encoder_model.py
DECODER=/mnt/d/riscv-work/riscv-trace-spec/referenceFlow/scripts/decoder_model.py

SCF=$WORKSPACE/my_hardware.scf
USER_CFG=$WORKSPACE/user_encoder.cfg
DSCF=$WORKSPACE/data_hardware.scf
USER_DATA_CFG=$WORKSPACE/user_data.cfg

LINKER=$CVA6_DIR/config/gen_from_riscv_config/linker/link.ld
COMMON=$CVA6_DIR/verif/tests/custom/common
ENV_INC=$CVA6_DIR/verif/tests/custom/env
DV_INC=$CVA6_DIR/verif/sim/dv/user_extension

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

#  ECLIPSE CONFIG

# Trigger file — tells TraceDecoderView that pipeline is done
TRIGGER_FILE="$WORKSPACE/pipeline_done.trigger"

# Runtime Eclipse launcher (exact command from Show Command Line)
JAVAW="/mnt/c/eclipse/plugins/org.eclipse.justj.openjdk.hotspot.jre.full.win32.x86_64_21.0.9.v20251105-0741/jre/bin/javaw.exe"
LAUNCHER_JAR="C:\\eclipse\\plugins\\org.eclipse.equinox.launcher_1.7.100.v20251111-0406.jar;"
RUNTIME_DATA="C:\\Users\\Iqra Jawad Ahmed\\runtime-EclipseApplication"
RUNTIME_CFG="file:///C:/Users/Iqra%20Jawad%20Ahmed/eclipse-workspace/.metadata/.plugins/org.eclipse.pde.core/Eclipse%20Application/"
RUNTIME_DEV="file:///C:/Users/Iqra%20Jawad%20Ahmed/eclipse-workspace/.metadata/.plugins/org.eclipse.pde.core/Eclipse%20Application/dev.properties"

#  VALIDATION HELPERS
ERRORS=0

check_file() {
    if [ ! -f "$1" ]; then
        echo "[ERROR] Required file not found: $1"
        ERRORS=$((ERRORS + 1))
    fi
}

check_tool() {
    if ! command -v "$1" &>/dev/null; then
        echo "[ERROR] Required tool not in PATH: $1"
        ERRORS=$((ERRORS + 1))
    fi
}

check_dir() {
    if [ ! -d "$1" ]; then
        echo "[ERROR] Required directory not found: $1"
        ERRORS=$((ERRORS + 1))
    fi
}

#  STEP 0: PRE-FLIGHT VALIDATION

echo "  MASTER TRACE PIPELINE"
echo "  Target : $TARGET_C"
echo "  Output : $WORKSPACE"

echo ""
echo "[STEP 0] Pre-flight validation..."

check_file "$TARGET_C"
check_tool "$GCC"
check_tool spike
check_tool python3
check_dir  "$CVA6_DIR"
check_dir  "$COMMON"
check_file "$VERILATOR_BIN"
check_file "$POSTISS"
check_file "$ENCODER"
check_file "$DECODER"
check_file "$LINKER"
check_file "$SCRIPT_DIR/gen_system_trace2.py"
check_file "$SCRIPT_DIR/func_exec_time.py"
check_file "$SCRIPT_DIR/correlate_misses.py"
check_file "$SCRIPT_DIR/finalize_profiling.py"

if [ "$ERRORS" -gt 0 ]; then
    echo ""
    echo "[FATAL] $ERRORS validation error(s) found. Fix above before running."
    exit 1
fi

echo "[OK] All pre-flight checks passed"

#  SETUP
mkdir -p "$WORKSPACE"
cd "$WORKSPACE"

# Remove old trigger file so Eclipse doesn't load stale data
rm -f "$TRIGGER_FILE"

#  STEP 1: CVA6 ENVIRONMENT
echo ""
echo "[STEP 1] Sourcing CVA6 environment..."
source "$CVA6_DIR/verif/sim/setup-env.sh"
echo "[OK] Environment ready"

#  STEP 2: COMPILE C → ELF
echo ""
echo "[STEP 2] Compiling $TARGET_C → $ELF_NAME ..."

$GCC "$TARGET_C" \
    -I"$DV_INC" \
    -T"$LINKER" \
    -static -mcmodel=medany -fvisibility=hidden -nostdlib -nostartfiles -g \
    "$COMMON/syscalls.c" \
    "$COMMON/crt.S" \
    -I"$ENV_INC" \
    -I"$COMMON" \
    -lgcc -o "$ELF_NAME" \
    -march=rv64gc_zba_zbb_zbs_zbc_zbkb_zbkx_zkne_zknd_zknh -mabi=lp64d 2>&1 | \
    grep -v "warning:" || true

if [ ! -f "$WORKSPACE/$ELF_NAME" ]; then
    echo "[FATAL] ELF not created — compilation failed"
    exit 1
fi

ELF_SIZE=$(stat -c%s "$WORKSPACE/$ELF_NAME")
if [ "$ELF_SIZE" -lt 100 ]; then
    echo "[FATAL] ELF too small ($ELF_SIZE bytes) — compilation likely failed"
    exit 1
fi

echo "[OK] ELF: $WORKSPACE/$ELF_NAME ($ELF_SIZE bytes)"

#  STEP 3: SPIKE → PC trace
echo ""
echo "[STEP 3] Spike simulation..."

spike --isa=rv64gc_zba_zbb_zbs_zbc_zbkb_zbkx_zkne_zknd_zknh \
    -l --log-commits \
    "$WORKSPACE/$ELF_NAME" \
    > spike_raw.log 2>&1 || true

if [ ! -f "spike_raw.log" ]; then
    echo "[FATAL] spike_raw.log not created"
    exit 1
fi

SPIKE_LINES=$(wc -l < spike_raw.log)
if [ "$SPIKE_LINES" -lt 10 ]; then
    echo "[FATAL] spike_raw.log too small ($SPIKE_LINES lines) — spike failed"
    exit 1
fi

echo "VALID,ADDRESS,INSN,PRIVILEGE,EXCEPTION,ECAUSE,TVAL,INTERRUPT" > spike_pc_trace.txt
grep "^core" spike_raw.log | grep " 3 " | awk '
/^core[ \t]+[0-9]+:[ \t]+[0-3][ \t]+0x00000000800/ {
    priv = $3; addr = $4; insn = $5
    sub("0x", "", addr)
    gsub("[()x]", "", insn)
    while(length(insn) > 4 && substr(insn,1,1)=="0") { insn = substr(insn, 2) }
    while(length(insn) < 4) { insn = "0" insn }
    printf "1,%s,%s,%s,0,0,0,0\n", addr, insn, priv
}' >> spike_pc_trace.txt

TRACE_LINES=$(( $(wc -l < spike_pc_trace.txt) - 1 ))
if [ "$TRACE_LINES" -lt 1 ]; then
    echo "[FATAL] No instructions in spike_pc_trace.txt — check spike_raw.log"
    exit 1
fi

echo "[OK] PC trace: spike_pc_trace.txt ($TRACE_LINES instructions)"

#  STEP 4: VERILATOR
echo ""
echo "[STEP 4] Verilator simulation..."

if [ "$MAX_CYCLES" -gt 0 ]; then
    "$VERILATOR_BIN" "$WORKSPACE/$ELF_NAME" "+max-cycles=$MAX_CYCLES" > simulation.log 2>&1 || \
        echo "[WARN] Verilator exited non-zero — check simulation.log"
else
    "$VERILATOR_BIN" "$WORKSPACE/$ELF_NAME" > simulation.log 2>&1 || \
        echo "[WARN] Verilator exited non-zero —> check simulation.log"
fi

if grep -qi "PASSED" simulation.log 2>/dev/null; then
    echo "[OK] Verilator PASSED"
elif grep -qi "FAILED" simulation.log 2>/dev/null; then
    echo "[WARN] Verilator FAILED —> profiling continues with Spike trace only"
else
    echo "[OK] Verilator done"
fi
#  STEP 5: WRITE CONFIG FILES
echo ""
echo "[STEP 5] Writing config files..."

cat > "$SCF" << 'SCFEOF'
[Required Attributes]
arch_p=0
bpred_size_p=0
cache_size_p=0
call_counter_size_p=0
context_width_p=32
time_width_p=1
ecause_width_p=5
f0s_width_p=0
iaddress_lsb_p=0
iaddress_width_p=64
nocontext_p=0
notime_p=1
privilege_width_p=2
return_stack_size_p=0
sijump_p=0
[Optional Filtering Attributes]
comparators_p=1
filters_p=1
ecause_choice_p=5
filter_context_p=1
filter_time_p=1
filter_excint_p=1
filter_privilege_p=1
filter_tval_p=1
[Other Recommended Attributes]
ctype_width_p=2
ilastsize_width_p=1
itype_width_p=3
iretire_width_p=3
retires_p=1
taken_branches_p=1
impdef_width_p=1
SCFEOF

cat > "$DSCF" << 'DSCFEOF'
[required]
arch_p=0
bpred_size_p=0
cache_size_p=0
call_counter_size_p=0
context_width_p=32
time_width_p=1
ecause_width_p=5
f0s_width_p=0
iaddress_lsb_p=0
iaddress_width_p=64
nocontext_p=0
notime_p=1
privilege_width_p=2
return_stack_size_p=0
sijump_p=0
daddress_width_p=64
dblock_width_p=8
data_width_p=64
dsize_width_p=3
dtype_width_p=4
iaddr_lsbs_width_p=0
lrid_width_p=0
lresp_width_p=0
ldata_width_p=0
sdata_width_p=0
DSCFEOF

cat > "$USER_CFG" << CFGEOF
[required]
file-stem = spike_pc_trace
object-files = ${WORKSPACE}/${ELF_NAME}
[codec]
resync-max = 1
full-address = true
implicit-except = false
si-jump = false
implicit-return = false
branch-prediction = false
jump-target-cache = false
[flags]
use-rv32-isa = false
CFGEOF

cat > "$USER_DATA_CFG" << DATACFGEOF
[required]
file-stem = spike_pc_trace
[codec]
no-data = false
no-address = false
full-daddress = false
full-data = false
data-compress = 0
[flags]
use-rv32-isa = false
DATACFGEOF

echo "[OK] Config files written"

#  STEP 6: POST-ISS
echo ""
echo "[STEP 6] Post-ISS..."

"$POSTISS" -c "$SCF" -i spike_pc_trace.txt

if [ ! -f "spike_pc_trace.encoder_input" ]; then
    echo "[FATAL] Post-ISS failed —> spike_pc_trace.encoder_input not found"
    exit 1
fi

cp spike_pc_trace.encoder_input spike_pc_trace_input
echo "[OK] Post-ISS done"


#  STEP 7: E-TRACE PIPELINE
echo ""
echo "[STEP 7] E-Trace encoding..."
python3 "$ENCODER" -c "$SCF" -u "$USER_CFG"

echo "[STEP 7] E-Trace decoding..."
if [ ! -f "spike_pc_trace_input.te_inst_raw" ]; then
    echo "[WARN] te_inst_raw not found — skipping decode"
else
    python3 "$DECODER" -c "$SCF" -u "$USER_CFG" -i spike_pc_trace_input.te_inst_raw
    echo "[OK] E-Trace decoded"

    tail -n +2 spike_pc_trace.txt | awk -F',' '{print $2}' | sed 's/^0*//' > spike_check.txt
    sed 's/^0*//' spike_pc_trace_input.decoder.trace > decoder_check.txt

    if diff spike_check.txt decoder_check.txt > /dev/null 2>&1; then
        echo "[OK] E-Trace MATCH — decode verified"
    else
        DIFF_COUNT=$(diff spike_check.txt decoder_check.txt | grep "^[<>]" | wc -l)
        echo "[WARN] E-Trace MISMATCH ($DIFF_COUNT differing lines)"
    fi
fi

#  STEP 8: SYSTEM TRACE
echo ""
echo "[STEP 8] Generating System Trace (gen_system_trace2.py)..."

HART_DASM="$WORKSPACE/trace_hart_0.dasm"
RVFI_DASM="$WORKSPACE/trace_rvfi_hart_00.dasm"
SYS_TRACE_TXT="$WORKSPACE/system_trace.txt"

if [ ! -f "$HART_DASM" ]; then
    echo "[WARN] trace_hart_0.dasm not found — skipping Step 8"
    STEP8_OK=0
elif [ ! -f "$RVFI_DASM" ]; then
    echo "[WARN] trace_rvfi_hart_00.dasm not found — skipping Step 8"
    STEP8_OK=0
else
    python3 "$SCRIPT_DIR/gen_system_trace2.py" \
        --hart  "$HART_DASM" \
        --rvfi  "$RVFI_DASM" \
        --elf   "$WORKSPACE/$ELF_NAME" \
        --out   "$SYS_TRACE_TXT" \
        --collapse-syscall

    if [ -f "$SYS_TRACE_TXT" ]; then
        ST_LINES=$(wc -l < "$SYS_TRACE_TXT")
        echo "[OK] system_trace.txt generated ($ST_LINES lines)"
        STEP8_OK=1
    else
        echo "[ERROR] system_trace.txt was not created"
        STEP8_OK=0
    fi
fi

#  STEP 9: FUNCTION EXECUTION TIME

echo ""
echo "[STEP 9] Function Execution Time (func_exec_time.py)..."

if [ "${STEP8_OK:-0}" -eq 0 ]; then
    echo "[SKIP] Step 8 did not complete —> skipping Step 9"
    STEP9_OK=0
else
    python3 "$SCRIPT_DIR/func_exec_time.py" \
        --trace  "$SYS_TRACE_TXT" \
        --outdir "$WORKSPACE"

    if [ -f "$WORKSPACE/function_exec_time.csv" ]; then
        echo "[OK] function_exec_time.csv ready"
        STEP9_OK=1
    else
        echo "[ERROR] function_exec_time.csv not created"
        STEP9_OK=0
    fi
fi

#  STEP 10: RTL CACHE MISS CORRELATION

echo ""
echo "[STEP 10] RTL Cache Miss Correlation (correlate_misses.py)..."

ICACHE_LOG="$WORKSPACE/icache_misses.log"
DCACHE_LOG="$WORKSPACE/dcache_misses.log"

if [ ! -f "$ICACHE_LOG" ] || [ ! -f "$DCACHE_LOG" ]; then
    echo "[SKIP] icache_misses.log or dcache_misses.log not found"
    STEP10_OK=0
else
    python3 "$SCRIPT_DIR/correlate_misses.py" \
        --icache "$ICACHE_LOG" \
        --dcache "$DCACHE_LOG" \
        --elf    "$WORKSPACE/$ELF_NAME" \
        --outdir "$WORKSPACE"

    if [ -f "$WORKSPACE/rtl_profiling_report.csv" ]; then
        echo "[OK] rtl_profiling_report.csv ready"
        STEP10_OK=1
    else
        echo "[ERROR] rtl_profiling_report.csv not created"
        STEP10_OK=0
    fi
fi

#  STEP 11: UNIFIED PROFILING REPORT
echo ""
echo "[STEP 11] Unified Profiling Report..."

if [ "${STEP9_OK:-0}" -eq 0 ]; then
    echo "[SKIP] function_exec_time.csv missing — cannot build unified report"
else
    RTL_ARG=""
    if [ -f "$WORKSPACE/rtl_profiling_report.csv" ]; then
        RTL_ARG="--rtl $WORKSPACE/rtl_profiling_report.csv"
    fi

    python3 "$SCRIPT_DIR/finalize_profiling.py" \
        --systrace "$WORKSPACE/function_exec_time.csv" \
        --systxt   "$WORKSPACE/system_trace.txt" \
        $RTL_ARG \
        --elf      "$WORKSPACE/$ELF_NAME" \
        --outdir   "$WORKSPACE"

    echo "[OK] Unified report complete"
fi

#  WRITE TRIGGER FILE
#  TraceDecoderView watches for this file
echo ""
echo "[TRIGGER] Writing pipeline_done.trigger..."
date +%s > "$TRIGGER_FILE"
echo "[OK] Trigger written → Eclipse will auto-load table"


#  LAUNCH ECLIPSE — Runtime with TraceDecoderView
echo ""
echo "[ECLIPSE] Launching Eclipse with TraceDecoderView..."

"$JAVAW" \
    -classpath "$LAUNCHER_JAR" \
    org.eclipse.equinox.launcher.Main \
    -launcher "C:\\eclipse\\eclipse.exe" \
    -product org.eclipse.platform.ide \
    -data "$RUNTIME_DATA" \
    -configuration "$RUNTIME_CFG" \
    -dev "$RUNTIME_DEV" \
    -os win32 -ws win32 -arch x86_64 -nl en_US &

echo "[OK] Eclipse launched —> table auto-loading pipeline results!"

#  DONE

echo ""
echo "============================================================"
echo "  PIPELINE COMPLETE"
echo ""
echo "  Key outputs in: $WORKSPACE"
echo "    simulation.elf                      — compiled firmware"
echo "    spike_raw.log                       — full spike log"
echo "    spike_pc_trace.txt                  — spike PC trace"
echo "    simulation.log                      — verilator log"
echo "    spike_pc_trace_input.decoder.trace  — E-Trace decoded"
echo "    system_trace.txt                    — merged hart+rvfi trace"
echo "    function_exec_time.csv              — cycle timing per function"
echo "    function_exec_time.txt              — human-readable timing"
echo "    rtl_profiling_report.csv            — RTL cache misses (if run)"
echo "    unified_profiling_report.csv        — Eclipse-ready unified"
echo "    unified_profiling_summary.txt       — unified human-readable"
echo "    pipeline_done.trigger               — auto-load signal for Eclipse"
echo "============================================================"
