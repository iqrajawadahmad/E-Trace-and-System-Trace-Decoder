#!/usr/bin/env python3
import re
import sys
import argparse
import subprocess
from collections import defaultdict

SYSCALL_MNEMONICS = {"ecall", "ebreak"}
BRANCH_MNEMONICS  = {"beq","bne","blt","bge","bltu","bgeu","c.beqz","c.bnez"}
CALL_MNEMONICS    = {"jal","c.jal","c.j"}
RET_MNEMONICS     = {"jalr","c.jalr","c.jr","ret"}
LOAD_MNEMONICS    = {"lb","lh","lw","ld","lbu","lhu","lwu","c.lw","c.ld","c.lwsp","c.ldsp"}
STORE_MNEMONICS   = {"sb","sh","sw","sd","c.sw","c.sd","c.swsp","c.sdsp"}

def classify_event(mnemonic: str) -> str:
    m = mnemonic.lower().split()[0]
    if m in SYSCALL_MNEMONICS: return "SYSCALL"
    if m in BRANCH_MNEMONICS:  return "BRANCH"
    if m in CALL_MNEMONICS:    return "CALL"
    if m in RET_MNEMONICS:     return "RET"
    if m in LOAD_MNEMONICS:    return "LOAD"
    if m in STORE_MNEMONICS:   return "STORE"
    return "EXEC"


HART_RE = re.compile(
    r'^\s*(\d+)\s+(0x[0-9a-fA-F]+)\s+\S+\s+\(0x([0-9a-fA-F]+)\)'
)

def parse_hart(path: str) -> dict:
    table = defaultdict(list)
    with open(path, "r", errors="replace") as f:
        for line in f:
            m = HART_RE.match(line)
            if m:
                cycle  = int(m.group(1))
                pc     = int(m.group(2), 16)
                opcode = m.group(3)
                table[pc].append((cycle, opcode))
    return table


RVFI_INST_RE = re.compile(
    r'^core\s+\d+:\s+(0x[0-9a-fA-F]+)\s+\(0x([0-9a-fA-F]+)\)'
)
RVFI_STATE_RE = re.compile(
    r'^\d+\s+0x[0-9a-fA-F]+\s+\(0x[0-9a-fA-F]+\)\s+(x\d+|pc)\s+(0x[0-9a-fA-F]+)'
)
RVFI_MEM_RE = re.compile(
    r'mem\s+(0x[0-9a-fA-F]+)(?:\s+(0x[0-9a-fA-F]+))?'
)

def parse_rvfi(path: str) -> list:
    records = []
    current = None
    with open(path, "r", errors="replace") as f:
        for line in f:
            line = line.rstrip()
            if line.startswith("***"):
                continue
            mi = RVFI_INST_RE.match(line)
            if mi:
                if current:
                    records.append(current)
                current = {
                    "pc":         int(mi.group(1), 16),
                    "opcode":     mi.group(2),
                    "reg_deltas": {},
                    "mem":        []
                }
                continue
            if current is None:
                continue
            ms = RVFI_STATE_RE.match(line)
            if ms:
                current["reg_deltas"][ms.group(1)] = int(ms.group(2), 16)
                continue
            mm = RVFI_MEM_RE.search(line)
            if mm:
                addr = int(mm.group(1), 16)
                val  = int(mm.group(2), 16) if mm.group(2) else 0
                rw   = "R" if re.search(r'\bx\s+\d+\s+0x', line[:line.index('mem')]) else "W"
                current["mem"].append((addr, rw, val))
    if current:
        records.append(current)
    return records


def load_symbols(elf_path: str) -> list:
    symbols = []
    try:
        out = subprocess.check_output(
            ["riscv64-unknown-elf-nm", "--defined-only", "-n", elf_path],
            stderr=subprocess.DEVNULL, text=True
        )
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[1] in ("T", "t", "W", "w"):
                try:
                    symbols.append((int(parts[0], 16), parts[2]))
                except ValueError:
                    pass
    except (FileNotFoundError, subprocess.CalledProcessError):
        try:
            out = subprocess.check_output(
                ["riscv64-unknown-elf-objdump", "-t", elf_path],
                stderr=subprocess.DEVNULL, text=True
            )
            for line in out.splitlines():
                parts = line.split()
                if len(parts) >= 6 and parts[2] == "F":
                    try:
                        symbols.append((int(parts[0], 16), parts[-1]))
                    except ValueError:
                        pass
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass
    symbols.sort()
    return symbols

def pc_to_func(pc: int, symbols: list) -> str:
    lo, hi = 0, len(symbols) - 1
    result = "?"
    while lo <= hi:
        mid = (lo + hi) // 2
        if symbols[mid][0] <= pc:
            result = symbols[mid][1]
            lo = mid + 1
        else:
            hi = mid - 1
    return result


# only these get collapsed — user functions (fibonacci, main, etc.) are never in here
NOISE_FUNCTIONS = {
    "syscall", "memset", "memcpy", "memcmp", "memmove",
    "strlen", "strcpy", "strcmp",
    "vprintfmt", "putchar", "puts", "printf", "sprintf",
    "printnum", "getint",
    "_init", "init_tls", "thread_entry",
    "?",
}

def is_noise(func: str) -> bool:
    return func in NOISE_FUNCTIONS

def is_htif_loop_pc(pc: int) -> bool:
    return 0x80000000 <= pc <= 0x80001FFF


def opcode_to_mnemonic(opcode_hex: str) -> str:
    try:
        w = int(opcode_hex, 16)
    except ValueError:
        return "???"

    if (w & 0x3) != 0x3:
        op2   = (w >> 13) & 0x7
        op_lo = w & 0x3
        if op_lo == 0x0:
            if op2 == 0x2: return "c.lw"
            if op2 == 0x6: return "c.sw"
            return "c.misc"
        if op_lo == 0x1:
            if op2 == 0x4:
                rs1 = (w >> 7) & 0x7
                if rs1 == 0: return "c.j"
                return "c.bnez" if ((w >> 13) & 0x7) == 0x7 else "c.beqz"
            return "c.arith"
        if op_lo == 0x2:
            if op2 == 0x4:
                bit12 = (w >> 12) & 1
                rs2   = (w >> 2) & 0x1f
                if rs2 == 0: return "c.jr" if not bit12 else "c.jalr"
                return "c.mv"
            return "c.misc"
        return "c.???"

    opcode = w & 0x7f
    funct3 = (w >> 12) & 0x7
    funct7 = (w >> 25) & 0x7f

    if opcode == 0x03: return ["lb","lh","lw","ld","lbu","lhu","lwu","???"][funct3]
    if opcode == 0x23: return ["sb","sh","sw","sd","???","???","???","???"][funct3]
    if opcode == 0x63: return ["beq","bne","???","???","blt","bge","bltu","bgeu"][funct3]
    if opcode == 0x6F: return "jal"
    if opcode == 0x67: return "jalr"
    if opcode == 0x37: return "lui"
    if opcode == 0x17: return "auipc"
    if opcode == 0x73:
        if w == 0x00000073: return "ecall"
        if w == 0x00100073: return "ebreak"
        return "csr"
    if opcode == 0x13:
        return ["addi","slli","slti","sltiu","xori","srli/srai","ori","andi"][funct3]
    if opcode == 0x33:
        if funct7 == 0x01:
            return ["mul","mulh","mulhsu","mulhu","div","divu","rem","remu"][funct3]
        return ["add","sll","slt","sltu","xor","srl/sra","or","and"][funct3]
    if opcode == 0x1B: return "addiw"
    if opcode == 0x3B: return "addw/subw"
    return f"op({opcode:#04x})"


IMPORTANT_REGS = {
    "x1":"ra","x2":"sp","x8":"s0/fp",
    "x10":"a0","x11":"a1","x12":"a2","x13":"a3",
    "x14":"a4","x15":"a5","x16":"a6","x17":"a7",
}

def format_reg_delta(reg_deltas: dict) -> str:
    parts = []
    for reg, val in reg_deltas.items():
        num = reg.lstrip("x")
        if num.isdigit():
            abi = IMPORTANT_REGS.get(f"x{num}", f"x{num}")
            parts.append(f"{abi}={val:#018x}")
        else:
            parts.append(f"{reg}={val:#018x}")
    return "  ".join(parts) if parts else "-"

def format_mem(mem_list: list) -> str:
    if not mem_list:
        return "-"
    return "  ".join(f"{rw}@{addr:#010x}={val:#010x}"
                     for addr, rw, val in mem_list)


def merge_and_write(hart_path, rvfi_path, elf_path, out_path, collapse_syscall):

    print(f"[*] Parsing hart trace  : {hart_path}")
    hart_table = parse_hart(hart_path)

    print(f"[*] Parsing rvfi trace  : {rvfi_path}")
    rvfi_records = parse_rvfi(rvfi_path)

    symbols = []
    if elf_path:
        print(f"[*] Loading ELF symbols : {elf_path}")
        symbols = load_symbols(elf_path)
        print(f"    {len(symbols)} symbols loaded.")

    print(f"[*] Writing output      : {out_path}")

    header = (
        f"{'CYCLE':>10}  {'PC':>18}  {'MNEMONIC':<12}  {'EVENT':<8}  "
        f"{'FUNC':<20}  {'REG_DELTA':<60}  MEM_ACCESS\n"
    )
    sep = "-" * 150 + "\n"

    total_written = 0
    collapsed     = 0

    hart_queue = {pc: list(entries) for pc, entries in hart_table.items()}
    hart_pos   = defaultdict(int)

    prev_pc        = None
    same_pc_run    = 0
    prev_func      = None
    noise_func_run = 0

    with open(out_path, "w") as out:
        out.write(header)
        out.write(sep)

        for rec in rvfi_records:
            pc     = rec["pc"]
            opcode = rec["opcode"]
            mn     = opcode_to_mnemonic(opcode)
            event  = classify_event(mn)
            func   = pc_to_func(pc, symbols) if symbols else "?"

            # htif busy-wait — collapse entirely
            if collapse_syscall and is_htif_loop_pc(pc):
                collapsed += 1
                if collapsed == 1:
                    out.write(
                        f"{'...':>10}  {'0x<htif-loop>':>18}  "
                        f"{'...':12}  {'SYSCALL':<8}  "
                        f"{'<tohost/fromhost>':<20}  "
                        f"{'[htif busy-wait collapsed]':<60}  -\n\n"
                    )
                    total_written += 1
                continue

            # same-PC loop collapse — noise functions only
            if pc == prev_pc and is_noise(func):
                same_pc_run += 1
                if same_pc_run == 4:
                    out.write(
                        f"{'...':>10}  {pc:#018x}  "
                        f"{'[loop]':12}  {'BRANCH':<8}  "
                        f"{func:<20}  "
                        f"{'[PC repeat collapsed]':<60}  -\n"
                    )
                    total_written += 1
                if same_pc_run >= 4:
                    collapsed += 1
                    continue
            else:
                same_pc_run = 0

            # noise function EXEC collapse — user functions always written in full
            if collapse_syscall and is_noise(func) and event == "EXEC":
                noise_func_run += 1
                if noise_func_run > 1:
                    collapsed += 1
                    prev_pc   = pc
                    continue
            else:
                if func != prev_func and noise_func_run > 1:
                    out.write(
                        f"{'...':>10}  {'':>18}  {'':12}  {'':8}  "
                        f"{prev_func:<20}  "
                        f"{f'[{noise_func_run} EXEC instructions collapsed]':<60}  -\n"
                    )
                    total_written += 1
                noise_func_run = 0

            prev_func = func
            prev_pc   = pc

            cycle = "?"
            if pc in hart_queue:
                idx = hart_pos[pc]
                if idx < len(hart_queue[pc]):
                    cycle = hart_queue[pc][idx][0]
                    hart_pos[pc] += 1

            reg_str = format_reg_delta(rec["reg_deltas"])
            mem_str = format_mem(rec["mem"])
            if len(reg_str) > 60:
                reg_str = reg_str[:57] + "..."

            line = (
                f"{str(cycle):>10}  {pc:#018x}  {mn:<12}  {event:<8}  "
                f"{func:<20}  {reg_str:<60}  {mem_str}\n"
            )
            out.write(line)
            total_written += 1

            if event in ("CALL", "RET"):
                out.write("\n")

        out.write(sep)
        out.write(f"\n[SUMMARY]\n")
        out.write(f"  Total instructions : {len(rvfi_records)}\n")
        out.write(f"  Written lines      : {total_written}\n")
        out.write(f"  Collapsed (noise)  : {collapsed}\n")

    print(f"[✓] Done. {total_written} lines written, {collapsed} noise lines collapsed.")


def main():
    ap = argparse.ArgumentParser(
        description="Merge hart + rvfi traces into a clean system trace."
    )
    ap.add_argument("--hart",  required=True,  help="trace_hart_0.dasm")
    ap.add_argument("--rvfi",  required=True,  help="trace_rvfi_hart_00.dasm")
    ap.add_argument("--elf",   default=None,   help="ELF binary (optional)")
    ap.add_argument("--out",   default="system_trace.txt", help="Output file")
    ap.add_argument("--collapse-syscall", action="store_true",
                    help="Collapse noise library functions and htif loops")
    args = ap.parse_args()

    merge_and_write(
        hart_path        = args.hart,
        rvfi_path        = args.rvfi,
        elf_path         = args.elf,
        out_path         = args.out,
        collapse_syscall = args.collapse_syscall
    )

if __name__ == "__main__":
    main()
