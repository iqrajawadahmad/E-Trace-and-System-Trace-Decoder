#!/usr/bin/env python3
"""
finalize_profiling.py
===================================================================
INPUTS:
  --systrace   function_exec_time.csv
  --systxt     system_trace.txt
  --rtl        rtl_profiling_report.csv
  --elf        simulation.elf
  --outdir     output directory

OUTPUTS:
  unified_profiling_report.csv
  unified_profiling_summary.txt
"""

import csv
import os
import re
import sys
import argparse
import subprocess
from collections import defaultdict

BOOTSTRAP = {
    "_start", "_start_text", "_init", "init_tls", "thread_entry",
    "__libc_start_main", "crt0", "_fini", "trap_entry",
}

def to_display(fn):
    return f"[SYS] {fn}" if fn in BOOTSTRAP else fn


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--systrace", required=True,  help="function_exec_time.csv")
    p.add_argument("--systxt",   default=None,   help="system_trace.txt (optional)")
    p.add_argument("--rtl",      default=None,   help="rtl_profiling_report.csv (optional)")
    p.add_argument("--etrace",   default=None,   help="(ignored)")
    p.add_argument("--elf",      required=True,  help="simulation.elf")
    p.add_argument("--outdir",   default=".",    help="Output directory")
    return p.parse_args()


def get_all_symbols(elf_path):
    symbols = []
    try:
        out = subprocess.check_output(
            ["riscv64-unknown-elf-nm", "--defined-only", "-n", elf_path],
            stderr=subprocess.DEVNULL, text=True
        )
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 3:
                addr_hex = parts[0]
                stype    = parts[1]
                name     = parts[2]
                if stype in ("T", "t", "W", "w") and name not in ("<unknown>", "?", ""):
                    try:
                        symbols.append({
                            "name":     name,
                            "addr_int": int(addr_hex, 16),
                            "addr_hex": "0x" + addr_hex.lstrip("0") or "0x0",
                        })
                    except ValueError:
                        continue
    except (FileNotFoundError, subprocess.CalledProcessError) as e:
        print(f"[WARN] nm failed: {e}")

    symbols.sort(key=lambda s: s["addr_int"])

    for i, sym in enumerate(symbols):
        if i + 1 < len(symbols):
            end_int = symbols[i + 1]["addr_int"] - 1
        else:
            end_int = sym["addr_int"]
        sym["end_hex"] = "0x{:x}".format(end_int)

    return symbols


def get_source_locations(elf_path, symbols):
    source_map = {}
    print(f"[*]   addr2line for {len(symbols)} functions...")
    for sym in symbols:
        try:
            out = subprocess.check_output(
                ["riscv64-unknown-elf-addr2line", "-e", elf_path, "-f", "-s",
                 sym["addr_hex"]],
                stderr=subprocess.DEVNULL, text=True
            )
            lines = [l.strip() for l in out.strip().splitlines() if l.strip()]
            if len(lines) >= 2:
                loc = lines[1]
                source_map[sym["name"]] = "unknown" if (loc.startswith("?") or loc == ":0") else loc
            else:
                source_map[sym["name"]] = "unknown"
        except (FileNotFoundError, subprocess.CalledProcessError):
            source_map[sym["name"]] = "unknown"

    found = sum(1 for v in source_map.values() if v != "unknown")
    print(f"[OK]  Source locations       : {found}/{len(symbols)} resolved")
    return source_map


def load_systrace(path):
    rows = {}
    if not os.path.isfile(path):
        print(f"[FATAL] function_exec_time.csv not found: {path}")
        sys.exit(1)
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            fn = row.get("FUNCTION", "").strip()
            if not fn or fn in ("<unknown>", "?", ""):
                continue
            rows[fn] = {
                "ENTRY_CYCLE":         row.get("ENTRY_CYCLE",         ""),
                "EXIT_CYCLE":          row.get("EXIT_CYCLE",          ""),
                "TOTAL_CYCLES":        row.get("TOTAL_CYCLES",        "0"),
                "PCT_OF_PROGRAM":      row.get("PCT_OF_PROGRAM",      ""),
                "CPI":                 row.get("CPI",                 ""),
                "MEM_INTENSITY":       row.get("MEM_INTENSITY",       ""),
                "INSTR_COUNT":         row.get("INSTR_COUNT",         "0"),
                "CALLS":               row.get("CALLS",               "0"),
                "AVG_CYCLES_PER_CALL": row.get("AVG_CYCLES_PER_CALL", ""),
                "EXEC":                row.get("EXEC",                "0"),
                "LOAD":                row.get("LOAD",                "0"),
                "STORE":               row.get("STORE",               "0"),
                "BRANCH":              row.get("BRANCH",              "0"),
            }
    print(f"[OK]  function_exec_time.csv : {len(rows)} functions  ({path})")
    return rows


ADDR_RE = re.compile(r'0x[0-9a-fA-F]+', re.IGNORECASE)

def load_systxt(path):
    if path is None:
        print(f"[INFO] system_trace.txt      : not provided")
        return {}
    if not os.path.isfile(path):
        print(f"[WARN] system_trace.txt      : not found: {path}")
        return {}

    data = defaultdict(lambda: {"load": 0, "store": 0, "addrs": set()})
    header_done = False

    with open(path) as f:
        for line in f:
            stripped = line.strip()
            if not header_done:
                if stripped.startswith("CYCLE") or stripped.startswith("-"):
                    header_done = True
                continue
            if not stripped:
                continue

            parts = re.split(r'\s{2,}', stripped)
            if len(parts) < 5:
                continue

            try:
                event = parts[3].strip()
                func  = parts[4].strip()
                reg_delta = parts[5].strip() if len(parts) > 5 else "-"

                if func in ("?", "", "-"):
                    continue

                if event == "LOAD":
                    data[func]["load"] += 1
                    m = ADDR_RE.search(reg_delta)
                    if m:
                        data[func]["addrs"].add(m.group(0).lower())
                elif event == "STORE":
                    data[func]["store"] += 1
                    m = ADDR_RE.search(reg_delta)
                    if m:
                        data[func]["addrs"].add(m.group(0).lower())

            except (IndexError, ValueError):
                continue

    result = {
        fn: {
            "mem_accesses":     d["load"] + d["store"],
            "unique_mem_addrs": len(d["addrs"]),
        }
        for fn, d in data.items()
    }
    print(f"[OK]  system_trace.txt       : {len(result)} functions parsed  ({path})")
    return result


def load_rtl(path):
    rows = {}
    if path is None:
        print(f"[INFO] rtl_profiling_report  : not provided")
        return rows
    if not os.path.isfile(path):
        print(f"[WARN] rtl_profiling_report  : not found: {path}")
        return rows
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            fn = row.get("function", "").strip()
            if not fn or fn in ("<unknown>", "?", ""):
                continue
            rows[fn] = {
                "ic":    int(row.get("icache_misses", 0) or 0),
                "dc":    int(row.get("dcache_misses", 0) or 0),
                "total": int(row.get("total_misses",  0) or 0),
            }
    print(f"[OK]  rtl_profiling_report   : {len(rows)} functions  ({path})")
    return rows


def safe_int(v):
    try:
        return int(v)
    except (ValueError, TypeError):
        return 0


def merge_all(symbols, source_map, systrace, systxt, rtl):
    merged = []

    for sym in symbols:
        fn = sym["name"]
        st = systrace.get(fn, {})
        sx = systxt.get(fn, {})
        rt = rtl.get(fn, {})

        merged.append({
            "FUNCTION":            to_display(fn),
            "PC_START":            sym["addr_hex"],
            "PC_END":              sym["end_hex"],
            "SOURCE_LOCATION":     source_map.get(fn, "unknown"),
            "ENTRY_CYCLE":         st.get("ENTRY_CYCLE",         ""),
            "EXIT_CYCLE":          st.get("EXIT_CYCLE",          ""),
            "TOTAL_CYCLES":        st.get("TOTAL_CYCLES",        ""),
            "PCT_OF_PROGRAM":      st.get("PCT_OF_PROGRAM",      ""),
            "CPI":                 st.get("CPI",                 ""),
            "MEM_INTENSITY":       st.get("MEM_INTENSITY",       ""),
            "CALLS":               st.get("CALLS",               ""),
            "AVG_CYCLES_PER_CALL": st.get("AVG_CYCLES_PER_CALL", ""),
            "INSTR_COUNT":         st.get("INSTR_COUNT",         ""),
            "EXEC":                st.get("EXEC",                ""),
            "LOAD":                st.get("LOAD",                ""),
            "STORE":               st.get("STORE",               ""),
            "BRANCH":              st.get("BRANCH",              ""),
            "MEM_ACCESSES":        str(sx["mem_accesses"])     if sx else "",
            "UNIQUE_MEM_ADDRS":    str(sx["unique_mem_addrs"]) if sx else "",
            "ICACHE_MISSES":       str(rt["ic"])    if rt else "",
            "DCACHE_MISSES":       str(rt["dc"])    if rt else "",
            "TOTAL_CACHE_MISSES":  str(rt["total"]) if rt else "",
        })

    profiled   = [r for r in merged if r["TOTAL_CYCLES"] != ""]
    unprofiled = [r for r in merged if r["TOTAL_CYCLES"] == ""]
    profiled.sort(key=lambda r: safe_int(r["TOTAL_CYCLES"]), reverse=True)

    print(f"[OK]  Merged           : {len(merged)} functions total  "
          f"({len(profiled)} profiled, {len(unprofiled)} ELF-only)")
    return profiled + unprofiled


FIELDS = [
    "FUNCTION", "PC_START", "PC_END", "SOURCE_LOCATION",
    "ENTRY_CYCLE", "EXIT_CYCLE", "TOTAL_CYCLES", "PCT_OF_PROGRAM",
    "CPI",
    "CALLS", "AVG_CYCLES_PER_CALL",
    "INSTR_COUNT", "EXEC", "LOAD", "STORE", "BRANCH",
    "MEM_ACCESSES", "UNIQUE_MEM_ADDRS",
    "MEM_INTENSITY",
    "ICACHE_MISSES", "DCACHE_MISSES", "TOTAL_CACHE_MISSES",
]

def write_csv(merged, outdir):
    path = os.path.join(outdir, "unified_profiling_report.csv")
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        w.writerows(merged)
    print(f"[OK]  CSV  -> {path}")


def write_txt(merged, outdir):
    path    = os.path.join(outdir, "unified_profiling_summary.txt")
    has_rtl = any(r["ICACHE_MISSES"] not in ("", "N/A") for r in merged)
    has_mem = any(r["MEM_ACCESSES"]  not in ("", "N/A") for r in merged)

    profiled = [r for r in merged if r["TOTAL_CYCLES"] != ""]
    total_cy = sum(safe_int(r["TOTAL_CYCLES"])  for r in profiled)
    total_in = sum(safe_int(r["INSTR_COUNT"])   for r in profiled)
    total_ic = sum(safe_int(r["ICACHE_MISSES"]) for r in merged if r["ICACHE_MISSES"] not in ("", "N/A"))
    total_dc = sum(safe_int(r["DCACHE_MISSES"]) for r in merged if r["DCACHE_MISSES"] not in ("", "N/A"))

    W   = 160
    SEP = "=" * W
    DIV = "-" * W

    with open(path, "w") as f:
        f.write(SEP + "\n")
        f.write("  UNIFIED PROFILING REPORT — CVA6 RISC-V\n")
        f.write("  Sources: function_exec_time.csv | system_trace.txt | rtl_profiling_report.csv | ELF addr2line\n")
        f.write(SEP + "\n\n")
        f.write(f"  Total program cycles   : {total_cy:>12,}\n")
        f.write(f"  Total instructions     : {total_in:>12,}\n")
        f.write(f"  Total I-Cache misses   : {total_ic:>12,}\n")
        f.write(f"  Total D-Cache misses   : {total_dc:>12,}\n")
        f.write(f"  Functions tracked      : {len(profiled):>12} profiled\n")
        f.write(f"  Functions in ELF       : {len(merged):>12} total\n")
        f.write("\n" + SEP + "\n\n")

        f.write(
            f"{'FUNCTION':<22} {'PC_START':<14} {'PC_END':<14} {'SOURCE':<20} "
            f"{'TOT_CYC':>10} {'%':>7} {'CPI':>6} "
            f"{'INSTRS':>7} {'CALLS':>6} {'AVG_CYC':>9} "
            f"{'EXEC':>6} {'LOAD':>6} {'STORE':>6} {'BRANCH':>7}"
        )
        if has_mem:
            f.write(f" {'MEM_ACC':>8} {'UNIQ_ADDR':>10} {'MEM_INT':>8}")
        if has_rtl:
            f.write(f" {'I$MISS':>7} {'D$MISS':>7} {'TOT_MISS':>9}")
        f.write("\n" + DIV + "\n")

        for r in merged:
            src = r["SOURCE_LOCATION"]
            src = ("..." + src[-17:]) if len(src) > 20 else src
            fn  = r["FUNCTION"]
            fn  = (fn[:21] + "~") if len(fn) > 22 else fn

            cyc = r["TOTAL_CYCLES"]        if r["TOTAL_CYCLES"]        != "" else "-"
            pct = r["PCT_OF_PROGRAM"]      if r["PCT_OF_PROGRAM"]      != "" else "-"
            cpi = r["CPI"]                 if r["CPI"]                 != "" else "-"
            ins = r["INSTR_COUNT"]         if r["INSTR_COUNT"]         != "" else "-"
            cal = r["CALLS"]               if r["CALLS"]               != "" else "-"
            avg = r["AVG_CYCLES_PER_CALL"] if r["AVG_CYCLES_PER_CALL"] != "" else "-"
            ex  = r["EXEC"]   if r["EXEC"]   != "" else "-"
            ld  = r["LOAD"]   if r["LOAD"]   != "" else "-"
            st  = r["STORE"]  if r["STORE"]  != "" else "-"
            br  = r["BRANCH"] if r["BRANCH"] != "" else "-"

            f.write(
                f"{fn:<22} {r['PC_START']:<14} {r['PC_END']:<14} {src:<20} "
                f"{cyc:>10} {pct:>7} {cpi:>6} "
                f"{ins:>7} {cal:>6} {avg:>9} "
                f"{ex:>6} {ld:>6} {st:>6} {br:>7}"
            )
            if has_mem:
                mem = r["MEM_ACCESSES"]     if r["MEM_ACCESSES"]     != "" else "-"
                unq = r["UNIQUE_MEM_ADDRS"] if r["UNIQUE_MEM_ADDRS"] != "" else "-"
                mit = r["MEM_INTENSITY"]    if r["MEM_INTENSITY"]    != "" else "-"
                f.write(f" {mem:>8} {unq:>10} {mit:>8}")
            if has_rtl:
                ic  = r["ICACHE_MISSES"]      if r["ICACHE_MISSES"]      != "" else "-"
                dc  = r["DCACHE_MISSES"]      if r["DCACHE_MISSES"]      != "" else "-"
                tot = r["TOTAL_CACHE_MISSES"] if r["TOTAL_CACHE_MISSES"] != "" else "-"
                f.write(f" {ic:>7} {dc:>7} {tot:>9}")
            f.write("\n")

        f.write("\n" + SEP + "\n\n")

        f.write("  TOP 5 HOTSPOTS (by cycle count):\n\n")
        f.write(f"  {'#':<3} {'FUNCTION':<22} {'PC_START':<14} {'PC_END':<14} "
                f"{'CYCLES':>10} {'%':>7} {'CPI':>6} {'INSTRS':>7} {'CALLS':>6}\n")
        f.write("  " + "-" * 90 + "\n")
        for i, r in enumerate(profiled[:5], 1):
            f.write(f"  {i:<3} {r['FUNCTION']:<22} {r['PC_START']:<14} {r['PC_END']:<14} "
                    f"{r['TOTAL_CYCLES']:>10} {r['PCT_OF_PROGRAM']:>7} "
                    f"{r['CPI'] if r['CPI'] != '' else '-':>6} "
                    f"{r['INSTR_COUNT']:>7} {r['CALLS']:>6}\n")

        if has_rtl:
            cache_sorted = sorted(
                [r for r in merged if r["TOTAL_CACHE_MISSES"] not in ("", "N/A")],
                key=lambda r: safe_int(r["TOTAL_CACHE_MISSES"]), reverse=True
            )
            if cache_sorted:
                f.write("\n  TOP 5 CACHE MISS HOTSPOTS:\n\n")
                f.write(f"  {'#':<3} {'FUNCTION':<22} {'PC_START':<14} {'I$MISS':>8} {'D$MISS':>8} {'TOTAL':>8}\n")
                f.write("  " + "-" * 67 + "\n")
                for i, r in enumerate(cache_sorted[:5], 1):
                    f.write(f"  {i:<3} {r['FUNCTION']:<22} {r['PC_START']:<14} "
                            f"{r['ICACHE_MISSES']:>8} {r['DCACHE_MISSES']:>8} "
                            f"{r['TOTAL_CACHE_MISSES']:>8}\n")

        if has_mem:
            mem_sorted = sorted(
                [r for r in merged if r["MEM_ACCESSES"] not in ("", "N/A")],
                key=lambda r: safe_int(r["MEM_ACCESSES"]), reverse=True
            )
            if mem_sorted:
                f.write("\n  TOP 5 MEMORY-INTENSIVE FUNCTIONS:\n\n")
                f.write(f"  {'#':<3} {'FUNCTION':<22} {'PC_START':<14} {'MEM_ACC':>8} "
                        f"{'LOAD':>7} {'STORE':>7} {'UNIQ_ADDR':>10} {'MEM_INT':>8}\n")
                f.write("  " + "-" * 85 + "\n")
                for i, r in enumerate(mem_sorted[:5], 1):
                    f.write(f"  {i:<3} {r['FUNCTION']:<22} {r['PC_START']:<14} "
                            f"{r['MEM_ACCESSES']:>8} {r['LOAD']:>7} {r['STORE']:>7} "
                            f"{r['UNIQUE_MEM_ADDRS']:>10} "
                            f"{r['MEM_INTENSITY'] if r['MEM_INTENSITY'] != '' else '-':>8}\n")

        f.write("\n" + SEP + "\n")

    print(f"[OK]  TXT  -> {path}")


def main():
    args = parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    print("\n" + "=" * 60)
    print("  FINALIZE PROFILING — CVA6 RISC-V  (v8 — CPI + MEM_INT)")
    print("=" * 60)

    symbols    = get_all_symbols(args.elf)
    source_map = get_source_locations(args.elf, symbols)

    systrace = load_systrace(args.systrace)
    systxt   = load_systxt(args.systxt)
    rtl      = load_rtl(args.rtl)

    if not systrace:
        print("[FATAL] function_exec_time.csv is empty — cannot proceed")
        sys.exit(1)

    merged = merge_all(symbols, source_map, systrace, systxt, rtl)

    print()
    write_csv(merged, args.outdir)
    write_txt(merged, args.outdir)

    print("\n" + "=" * 60)
    print("  DONE:")
    print("    unified_profiling_report.csv")
    print("    unified_profiling_summary.txt")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
