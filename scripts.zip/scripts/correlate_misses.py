#!/usr/bin/env python3
import csv, subprocess, argparse, os
from collections import defaultdict

parser = argparse.ArgumentParser()
parser.add_argument("--icache", required=True)
parser.add_argument("--dcache", required=True)
parser.add_argument("--elf",    required=True)
parser.add_argument("--outdir", required=True)
args = parser.parse_args()

os.makedirs(args.outdir, exist_ok=True)

nm_out = subprocess.check_output(
    ["riscv64-unknown-elf-nm", "--numeric-sort", "--print-size", args.elf],
    stderr=subprocess.DEVNULL
).decode("utf-8", errors="replace")

symbols = []
for line in nm_out.splitlines():
    parts = line.split()
    if len(parts) == 4:
        try:
            addr = int(parts[0], 16)
            size = int(parts[1], 16)
            if parts[2].lower() in ("t", "w"):
                symbols.append((addr, size, parts[3]))
        except ValueError:
            pass

symbols.sort(key=lambda x: x[0])
func_map = {}
for i, (addr, size, name) in enumerate(symbols):
    end = symbols[i+1][0] if (size == 0 and i+1 < len(symbols)) else addr + max(size, 4)
    func_map[addr] = (name, end)

sorted_addrs = sorted(func_map.keys())

def pc_to_func(pc_str):
    try:
        pc = int(pc_str.strip(), 16)
    except ValueError:
        return "<unknown>"
    lo, hi, result = 0, len(sorted_addrs)-1, None
    while lo <= hi:
        mid = (lo+hi)//2
        if sorted_addrs[mid] <= pc:
            result = sorted_addrs[mid]
            lo = mid+1
        else:
            hi = mid-1
    if result is None:
        return "<unknown>"
    name, end = func_map[result]
    return name if pc < end else "<unknown>"

ic = defaultdict(int)
dc = defaultdict(int)

with open(args.icache) as f:
    for row in csv.DictReader(f):
        ic[pc_to_func(row.get("pc_hex","").replace("0x",""))] += 1

with open(args.dcache) as f:
    for row in csv.DictReader(f):
        dc[pc_to_func(row.get("addr_hex","").replace("0x",""))] += 1

funcs = sorted(set(ic)|set(dc), key=lambda f: ic[f]+dc[f], reverse=True)

CSV_OUT = os.path.join(args.outdir, "rtl_profiling_report.csv")
with open(CSV_OUT, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["function","icache_misses","dcache_misses","total_misses"])
    w.writeheader()
    for fn in funcs:
        w.writerow({"function":fn,"icache_misses":ic[fn],"dcache_misses":dc[fn],"total_misses":ic[fn]+dc[fn]})

TXT_OUT = os.path.join(args.outdir, "rtl_profiling_summary.txt")
with open(TXT_OUT, "w") as f:
    sep = "="*60
    f.write(sep+"\n  RTL CACHE MISS REPORT\n"+sep+"\n\n")
    f.write(f"  Total I-Cache misses : {sum(ic.values())}\n")
    f.write(f"  Total D-Cache misses : {sum(dc.values())}\n\n")
    f.write(f"{'Function':<25} {'I$Miss':>8} {'D$Miss':>8} {'Total':>8}\n")
    f.write("-"*55+"\n")
    for fn in funcs:
        f.write(f"{fn:<25} {ic[fn]:>8} {dc[fn]:>8} {ic[fn]+dc[fn]:>8}\n")
    f.write("\n"+sep+"\n")

print(f"[OK] {CSV_OUT}")
print(f"[OK] {TXT_OUT}")
print("[DONE] RTL correlation complete!")
